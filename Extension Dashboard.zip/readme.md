First Install ------> npm install

then run the -------> npm start


then live your server with VS Code Extension...